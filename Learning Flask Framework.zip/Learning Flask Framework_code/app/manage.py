from app import manager
from main import *

if __name__ == '__main__':
    manager.run()
